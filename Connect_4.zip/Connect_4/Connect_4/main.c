#include "header.h"


void main(void) {

	srand((unsigned)time(NULL));
	int current_player = who_starts();
	int move;
	bool playing = true;
	char board[ROWS][COLS];
	char piece1 = 'X';
	char piece2 = 'O';

	main_menu();
	initialize_game_board(board);

	while (playing == true) {
		while (current_player == 0) {
			printf("---Player 1's turn---\n\n");
			display_board(board);
			printf("Where would you like to place your piece?");
			scanf("%d", &move);
			system("CLS");
			place_piece(board, piece1, move);
			check_winner(board, current_player);

			current_player = 1;
		}
		while(current_player == 1) {
			printf("---Player 2's turn---\n\n");
			display_board(board);
			printf("Where would you like to place your piece?");
			scanf("%d", &move);
			system("CLS");
			place_piece(board, piece2, move);
			check_winner(board, current_player);

			current_player = 0;
		}
	}
}