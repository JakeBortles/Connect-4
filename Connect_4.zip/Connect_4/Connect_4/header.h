#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include <math.h>
#include <stdbool.h>
#include <stdlib.h>
#include <time.h>
#define ROWS 6
#define COLS 7

void main_menu();
void initialize_game_board(char board[ROWS][COLS]);
int who_starts();
void display_board(char board[ROWS][COLS]);
void place_piece(char board[ROWS][COLS], char piece);
void check_winner(char board[ROWS][COLS], char piece);
void exit_game();