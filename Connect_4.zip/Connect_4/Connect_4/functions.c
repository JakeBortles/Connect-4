#include "header.h"

void main_menu() {
	printf("---Welcome to connect 4---\n\n");

	printf("press any key to continue...");
	_getch("\n");
	system("CLS");
}
void initialize_game_board(char board[ROWS][COLS]) {
	for (int rows = 0; rows < ROWS; rows++) {
		for (int cols = 0; cols < COLS; cols++) {
			board[rows][cols] = '*';
		}
	}
}
int who_starts() {
	int starter = rand() % 2;

	if (starter == 0) {
		return 0;
	}
	else {
		return 1;
	}
}
void display_board(char board[ROWS][COLS]) {
	printf("0 1 2 3 4 5 6\n");
	for (int rows = 0; rows < ROWS; rows++) {
		for (int cols = 0; cols < COLS; cols++) {
			printf("%c ", board[rows][cols]);
		}
		printf("\n");
	}
}
void place_piece(char board[ROWS][COLS], char piece, int move) {
	int i = 0;
	while (board[i][move] == '*') {
		i++;
	}
	board[i - 1][move] = piece;
}
void check_winner(char board[ROWS][COLS], int current_player) {
	if (current_player == 0) { //checks horrizontal
		for (int rows = 0; rows < ROWS; rows++) {
			int count = 0;
			for (int cols = 0; cols < COLS; cols++) {
				if (board[rows][cols] == 'X') {
					count++;
				}
				else {
					count = 0;
				}
				if (count == 4) {
					printf("Player 1 wins!!\n\n");
					display_board(board);
					exit_game();
				}
			}
		}
		for (int rows = 0; rows < ROWS; rows++) { //checks vertical
			int count = 0;
			for (int cols = 0; cols < COLS; cols++) {
				if (board[cols][rows] == 'X') {
					count++;
				}
				else {
					count = 0;
				}
				if (count == 4) {
					printf("Player 1 wins!!\n\n");
					display_board(board);
					exit_game();
				}
			}
		}
		for (int cols = 0; cols > 7; cols++) { //checks diagonal (down-left to right)
			int count = 0;
			for (int rows = 2; rows < 6; rows++) {
				if (board[rows][cols] == 'X') {
					count++;
					cols++;
				}
				else {
					count = 0;
				}
				if (count == 4) {
					printf("Player 1 wins!!\n\n");
					display_board(board);
					exit_game();
				}
			}
		}
	}
	if (current_player == 1) {
		for (int rows = 0; rows < ROWS; rows++) { //checks horrizontal
			int count = 0;
			for (int cols = 0; cols < COLS; cols++) {
				if (board[rows][cols] == 'O') {
					count++;
				}
				else {
					count = 0;
				}
				if (count == 4) {
					printf("Player 2 wins!!\n\n");
					display_board(board);
					exit_game();
				}
			}
		}
		for (int rows = 0; rows < ROWS; rows++) { //checks vertical
			int count = 0;
			for (int cols = 0; cols < COLS; cols++) {
				if (board[cols][rows] == 'O') {
					count++;
				}
				else {
					count = 0;
				}
				if (count == 4) {
					printf("Player 2 wins!!\n\n");
					display_board(board);
					exit_game();
				}
			}
		}
		for (int cols = 0; cols > 7; cols++) { //checks diagonal (down-left to right)
			int count = 0;
			for (int rows = 2; rows < 6; rows++) {
				if (board[rows][cols] == 'X') {
					count++;
					cols++;
				}
				else {
					count = 0;
				}
				if (count == 4) {
					printf("Player 1 wins!!\n\n");
					display_board(board);
					exit_game();
				}
			}
		}
	}
}
void exit_game() {
	exit(0);
}